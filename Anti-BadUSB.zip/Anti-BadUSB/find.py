from usb_manager import UsbManager
UsbManager().show()