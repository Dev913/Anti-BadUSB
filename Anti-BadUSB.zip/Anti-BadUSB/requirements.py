from os import system
system('sudo pip install usb-manager')
system('sudo pip install exit')
