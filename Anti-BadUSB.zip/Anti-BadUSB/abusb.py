# CODE BELOW: Imports the required prequisites/modules!
from os import system
import os
import pynput
import yaml
import time
import random
import exit
from pynput.mouse import Button, Controller
import keyboard
# CODE BELOW: Defines "on_exit"
# "on_exit" states if user attempts to exit
# the script will see such and TAKE ACTION
# BY PROCEEDING TO SHUTDOWN!
def on_exit():
    system('sudo shutdown now')
# CODE BELOW: Defines what mouse is... CONTROLLER!    
mouse = Controller()

# CODE BELOW: Opens the configuration file
with open('Data/Data.yaml', 'r') as data:
    data = yaml.load(data)
# CODE BELOW: Defines the delay, and buttcombo then resets terminal
# then generates a random number in a stirng form from 1, 777
delay = data['delay']
buttcombo = data['buttcombo']
system('reset')
number = str(random.randint(1, 777))

# CODE BELOW: Repeats the code indented below "for i in range(999):
# FOR 999x
for i in range(999):
    time.sleep(delay)
    mouse.position = (999, 335)
    # CODE BELOW: Runs COMMMAND "python find.py" and writes such output
    # to "output.txt"
    system('python find.py > output.txt')
    # CODE BELOW: Repeats 99x
    # then moves mouse to screen coords (999, 335)
    for i in range(999):
        mouse.position = (999, 335)
    # CODE BELOW: Says if "Device" is found in "output.txt" then print
    # "USB FOUND!" then will proceed to repeat again 999x in order to see
    # devices are found and if such devices are found such script WILL proceed to
    # Shutdown Computer! If USB is NOT found it will search again and wait for hidden exit
    # to be initiated!
    if "Device" in open('output.txt').read():
        print('USB FOUND!')
        for i in range(999):
            mouse.position = (999, 335)
            print('SHUTTING DOWN!')
            system('sudo shutdown now')                
    else:
        print('USB NOT FOUND! Starting Search Again!!!')
        if keyboard.is_pressed(buttcombo):
            system('python')