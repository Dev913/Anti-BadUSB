from os import system
import os
import pynput
import yaml
import time
import random
import exit
from pynput.mouse import Button, Controller
import keyboard

def on_exit():
    system('sudo shutdown now')

exit.register(on_exit)

mouse = Controller()

with open('Data/Data.yaml', 'r') as data:
    data = yaml.load(data)
delay = data['delay']
buttcombo = data['buttcombo']
time.sleep(delay)
system('reset')
number = str(random.randint(1, 777))

for i in range(999):
    mouse.position = (999, 335)

    system('python find.py > output.txt')

    for i in range(999):
        mouse.position = (999, 335)

    if "Device" in open('output.txt').read():
        print('USB FOUND!')
        for i in range(999):
            mouse.position = (999, 335)
            print('SHUTTING DOWN!')
            system('sudo shutdown now')                
    else:
        print('USB NOT FOUND! Starting Search Again!!!')
        if keyboard.is_pressed(buttcombo):
            system('python')